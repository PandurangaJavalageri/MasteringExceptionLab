﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task3
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int n1, n2;
            n1=int.Parse(Console.ReadLine());
            n2=int.Parse(Console.ReadLine());
            try
            {
                if (n2 == 0)
                {
                    throw new InvalidInputException("division cannot be done","undefine",0);
                }
            }
            catch (InvalidInputException ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.InputValue);
                Console.WriteLine(ex.Reason);
            }
        }
    }
    public class InvalidInputException:ApplicationException
    {

        public int InputValue {  get; set; }
        public string Reason {  get; set; }
        public InvalidInputException(string msg,string Reason,int InputValue):base(msg)
        {
            this.Reason = Reason;
            this.InputValue = InputValue;
        }
    }
}
