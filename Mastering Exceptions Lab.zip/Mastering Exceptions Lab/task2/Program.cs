﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace task2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int n = int.Parse(Console.ReadLine());
                int m = int.Parse(Console.ReadLine());
                try
                {
                    int ans = n / m;
                }
                catch (DivideByZeroException ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    
    }
}
