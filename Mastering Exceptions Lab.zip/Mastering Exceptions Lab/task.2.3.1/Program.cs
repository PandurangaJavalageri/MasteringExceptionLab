﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task._2._3._1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try {

                fun1();

            }
            catch(Exception e) 
            {
                Console.WriteLine(e.StackTrace);
            }
        }

        public static void fun1()
        {
           /* try
            {*/

                fun2();

           /* }
            catch (Exception e)
            {
                throw e;
            }*/
        }

        public static void fun2()
        {
            try
            {

                fun3();

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static void fun3()
        {
            try
            {

                int a = 0;
                int c = 8 / a;

            }
            catch(Exception e) 
            {
                throw;
            }
        }


    }
}
