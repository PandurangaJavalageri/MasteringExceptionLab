﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task_2._3
{
    public class Program
    {
        static void Main(string[] args)
        {

            try
            {
                fun();
            }
            catch (ArithmeticException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


        }
        public static void fun()
        {
            int maxi = int.MaxValue;
            maxi = maxi + 1;
            int max = int.MaxValue;
            if (maxi + 1 < max)
            {
                throw new ArithmeticException("it has crosse a integer range");
            }
        }


    }
}