﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mastering_Exceptions_Lab
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1, n2;
            Console.WriteLine("enter two numbers");
            n1 =int.Parse(Console.ReadLine());
            n2=int.Parse(Console.ReadLine());
            int[] n=new int[] { 1,2,3 };
            try
            {
                if (n2 == 0)
                {
                    throw new DivideByZeroException();
                }

                else 
                {
                    double ans = n1 / n2;
                    Console.WriteLine(ans);
                }
                if(n2>=n.Length)
                {
                    throw new IndexOutOfRangeException("index is out of range");
                }
                else
                {
                    double ans2 = n1 / n[n2];
                    Console.WriteLine(ans2);
                }
            }
            catch(DivideByZeroException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(IndexOutOfRangeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("try catch block is completed");
            }

        }
    }

}
